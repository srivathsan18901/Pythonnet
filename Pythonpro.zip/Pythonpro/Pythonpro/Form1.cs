using System;
using System.Windows.Forms;
using Python.Runtime;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pythonpro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (Py.GIL()) 
            {
                dynamic py = Py.Import("PythonApplication1"); 
                try
                {
                    
                    double num1 = double.Parse(textBox1.Text);
                    double num2 = double.Parse(textBox2.Text);

                    dynamic result = py.add_numbers(num1, num2);

                    // Set the result in the third TextBox
                    textBox3.Text = result.ToString();
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that may occur
                    MessageBox.Show("Error: " + ex.Message);
                }
            } // GIL is released automatically
        }
    }
}